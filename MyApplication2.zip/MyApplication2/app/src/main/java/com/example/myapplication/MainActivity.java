package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity<TgStreamReader> extends AppCompatActivity {

    InputStream EastStream;
    InputStream NorthStream;
    InputStream SouthStream;
    InputStream WestStream;

    double sum=0D;
    int a=0;

    private BluetoothAdapter bluetoothAdapter;
    private TgStreamReader tgStreamReader;

    private short raw_data[] = {0};
    private int raw_data_index= 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EastStream = getResources().openRawResource(R.raw.meast);
        NorthStream = getResources().openRawResource(R.raw.mnorth);
        SouthStream = getResources().openRawResource(R.raw.msouth);
        WestStream = getResources().openRawResource(R.raw.mwest);


        try {
            // (1) Make sure that the device supports Bluetooth and Bluetooth is on
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
                Toast.makeText(
                        this,
                        "Please enable your Bluetooth and re-run this program !",
                        Toast.LENGTH_LONG).show();
                //finish();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("TAG", "error:" + e.getMessage());
            return;
        }
        @Override
        protected void onResume(){
            connect();
            super.onResume();
        }

        private void connect() {
            raw_data = new short[512];
            raw_data_index = 0;

             tgStreamReader = new TgStreamReader(bluetoothAdapter, callback);

            if(tgStreamReader != null && tgStreamReader.isBTConnected()){

                // Prepare for connecting
                tgStreamReader.stop();
                tgStreamReader.close();
            }

            // (4) Demo of  using connect() and start() to replace connectAndStart(),
            // please call start() when the state is changed to STATE_CONNECTED
            tgStreamReader.connect();
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(EastStream));

        try {
            String CsvLine;

            while ((CsvLine = reader.readLine()) != null) {
                String[] data = CsvLine.split(",");

                try {

                    sum = sum + Double.parseDouble(data[1].toString());
                    a++;
                    if (a == 10) {
                        double Avg=sum/10;
                        Log.e("EastAvg", "Average of 10Data : " + Avg);
                        a = 0;
                        sum = 0D;
                    }

                } catch (Exception e) {
                    Log.e("Problem", e.toString());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        BufferedReader reader1 = new BufferedReader(new InputStreamReader(NorthStream));

        try{
            String CsvLine;

            while((CsvLine=reader1.readLine())!=null){
                String[] data1= CsvLine.split(",");
                try {
                    sum=sum + Double.parseDouble(data1[1].toString());
                    a++;

                    if(a==10){
                        double Avg1=sum/10;
                        Log.e("NorthAvg","Average of 10Data :" +Avg1);
                        a=0;
                        sum=0D;
                    }

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        BufferedReader reader2 = new BufferedReader(new InputStreamReader(SouthStream));

        try{
            String CsvLine;

            while((CsvLine=reader2.readLine())!=null){
                String[] data2= CsvLine.split(",");
                try {
                    sum=sum + Double.parseDouble(data2[1].toString());
                    a++;

                    if(a==10){
                        double Avg2=sum/10;
                        Log.e("SouthAvg","Average of 10Data :" +Avg2);
                        a=0;
                        sum=0D;
                    }

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        BufferedReader reader3 = new BufferedReader(new InputStreamReader(WestStream));

        try{
            String CsvLine;

            while((CsvLine=reader3.readLine())!=null){
                String[] data3= CsvLine.split(",");
                try {
                    sum=sum + Double.parseDouble(data3[1].toString());
                    a++;

                    if(a==10){
                        double Avg3=sum/10;
                        Log.e("WestAvg","Average of 10Data :" +Avg3);
                        a=0;
                        sum=0D;
                    }

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}